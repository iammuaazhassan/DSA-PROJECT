#ifndef TASKMANAGER_H
#define TASKMANAGER_H
#include "Task.h"
#include <string>

using namespace std;

class TaskPriorityQueue;

class TaskManager : public Task
{
    private:
        TaskPriorityQueue* priority_queue_;

    public:
        Task task;

        TaskManager* prev_task ;
        TaskManager* next_task ;


        TaskManager* HEAD = nullptr ;

        void add_task();

        void remove_task(const string&);

        void update_task_priority(const string&,int);
        void update_task_name(const string&,const string&);
        void update_task_date(const string& ,const string& );

        Task* find_task_by_name(const string& );
        Task* find_task_by_priority(int );

        bool isPriorityAvailable(int );

        void sort_tasks_by_priority();
        void swap_tasks(TaskManager*,TaskManager*);

        void display_task_names();
        void display_task_details();





        TaskManager();
        virtual ~TaskManager();


};

#endif // TASKMANAGER_H
