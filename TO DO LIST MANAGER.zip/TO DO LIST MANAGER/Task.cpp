    #include "Task.h"
    #include <string>

    Task ::Task()
    {
        taskname = "----" ;
        date = "dd-mm-yyyy" ;
        priority = 0 ;
        //ctor
    }

    Task ::~Task()
    {
        //dtor
    }

    string Task :: get_taskname()
    {
        string NAME ;
        cout << "\nEnter the TASK NAME : " ;
        cin.ignore();
        getline(cin , NAME);
        return NAME ;
    }

    void Task :: set_taskname(string NAME)
    {
        taskname = NAME ;
    }

    string Task :: get_date()
    {
        string DATE ;
        cout << "Enter the DUE DATE : " ;
        cin.ignore();
        getline(cin , DATE);
        return DATE ;
    }

    void Task :: set_date(string DATE)
    {
        date = DATE ;
    }

    int Task :: get_priority()
    {
        int PRIORITY ;
        cout << "Enter the PRIORITY : " ;
        cin >> PRIORITY ;
        return PRIORITY ;
    }

    void Task :: set_priority(int PRIORITY)
    {
        priority = PRIORITY ;
    }

    void Task :: display_task_name()
    {
        cout << "TASK: " << taskname << endl;
    }

    void Task :: display()
    {
        cout << "\nTASK: " << taskname  ;
        cout << "\nDATE: " << date ;
        cout << "\nPRIORITY # " << priority ;
        cout << endl ;
    }
