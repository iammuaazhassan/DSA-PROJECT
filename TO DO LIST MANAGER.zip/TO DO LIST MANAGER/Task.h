#ifndef TASK_H
#define TASK_H


#include <iostream>
#include <string>

using namespace std;

class Task
{

    public:
        string taskname ;
        string date ;
        int priority;

        string get_taskname();
        void set_taskname(string);
        string get_date();
        void set_date(string);
        int get_priority();
        void set_priority(int);

        void display_task_name();
        void display();

        Task();
        virtual ~Task();



};

#endif // TASK_H
