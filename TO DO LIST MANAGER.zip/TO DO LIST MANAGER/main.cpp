#include <iostream>
#include "TaskManager.h"
#include "TaskPriorityQueue.h"

using namespace std;

int main()
{

    TaskManager taskManager;
    TaskPriorityQueue priorityQueue;

    Task* task1 = new Task();
    task1->set_taskname("ASSINGMENTS OF DSA");
    task1->set_date("2024-01-23");
    task1->set_priority(3);
    taskManager.HEAD = new TaskManager();
    taskManager.HEAD->task = *task1;

    Task* task2 = new Task();
    task2->set_taskname("DSA FINAL PROJECT");
    task2->set_date("2024-01-17");
    task2->set_priority(1);
    TaskManager* newTask2 = new TaskManager();
    newTask2->task = *task2;
    newTask2->prev_task = taskManager.HEAD;
    taskManager.HEAD->next_task = newTask2;

    Task* task3 = new Task();
    task3->set_taskname("DSA LAB FINAL");
    task3->set_date("2024-01-19");
    task3->set_priority(2);
    TaskManager* newTask3 = new TaskManager();
    newTask3->task = *task3;
    newTask3->prev_task = newTask2;
    newTask2->next_task = newTask3;

    TaskManager* newTask = new TaskManager;

    int choice = 0 ;
    do
    {
        cout << "\n ======================================================" ;
        cout << "\n|                    ----------                       |" ;
        cout << "\n|                       MENU                          |" ;
        cout << "\n|                    ----------                       |" ;
        cout << "\n|\t CHOOSE 1 TO ADD TASK                         |" ;
        cout << "\n|\t CHOOSE 2 TO REMOVE TASK                      |" ;
        cout << "\n|\t CHOOSE 3 TO UPDATE TASK                      |" ;
        cout << "\n|\t CHOOSE 4 TO FIND TASK                        |" ;
        cout << "\n|\t CHOOSE 5 TO DISPLAY TASK LIST                |" ;
        cout << "\n|\t                                              |" ;
        cout << "\n|\t CHOOSE 6 TO ENQUEUE TASK INTO PRIORITY QUEUE |" ;
        cout << "\n|\t CHOOSE 7 TO DEQUEUE TASK FROM PRIORITY QUEUE |" ;
        cout << "\n|\t CHOOSE 8 TO SORT THE TASK IN QUEUE           |" ;
        cout << "\n|\t                                              |" ;
        cout << "\n|\t CHOOSE 0 TO EXIT MENU                        |" ;
        cout << "\n|\t                                              |" ;
        cout << "\n ======================================================" ;

        cout << "\n ENTER YOUR CHOICE : " ;
        cin >> choice ;

        if(choice==1)
        {
            taskManager.add_task();
        }
        else if(choice==2)
        {
            string task_to_remove ;
            cout << "\n\tEnter the TASK NAME to remove : " ;
            cin >> task_to_remove ;
            taskManager.remove_task(task_to_remove);
        }
        else if(choice==3)
        {
            cout << "\n\t=============================================" ;
            cout << "\n\t|\t CHOOSE 1 TO UPDATE TASK NAME       |" ;
            cout << "\n\t|\t CHOOSE 2 TO UPDATE TASK PRIORITY   |" ;
            cout << "\n\t=============================================" ;
            cout << "\n\t ENTER YOUR CHOICE : " ;
            cin >> choice ;
            if(choice==1)
            {
                string currentName, newName;
                cout << "\n\tEnter the CURRENT TASK NAME: ";
                cin >> currentName;
                cout << "\n\tEnter the NEW TASK NAME: ";
                cin >> newName;
                taskManager.update_task_name(currentName, newName);
            }
            else if(choice==2)
            {
                string taskName;
                int newPriority;
                cout << "Enter the TASK NAME: ";
                cin >> taskName;
                cout << "Enter the new PRIORITY: ";
                cin >> newPriority;
                taskManager.update_task_priority(taskName, newPriority);
            }
            else
            {
                cout << "\n\n\t\t===INVAILD CHOICE===" ;
            }
        }
        else if(choice==4)
        {
            cout << "\n\t=============================================" ;
            cout << "\n\t|\t CHOOSE 1 TO FIND TASK BY NAME      |" ;
            cout << "\n\t|\t CHOOSE 2 TO FIND TASK BY PRIORITY  |" ;
            cout << "\n\t=============================================" ;
            cout << "\n\t ENTER YOUR CHOICE : " ;
            cin >> choice ;

            if(choice==1)
            {
                string taskName;
                cout << "Enter the TASK NAME TO FIND: ";
                cin >> taskName;
                Task* foundTask = taskManager.find_task_by_name(taskName);
                if (foundTask != nullptr)
                {
                    cout << "=== TASK FOUND === \n\t\t ";
                    foundTask->display();
                }
            }
            else if(choice==2)
            {
                int priority;
                cout << "Enter the TASK PRIORITY TO FIND: ";
                cin >> priority;
                Task* foundTask = taskManager.find_task_by_priority(priority);
                if (foundTask != nullptr) {
                    cout << "=== TASK FOUND === \n\t\t ";
                    foundTask->display();
                }
            }
            else
            {
                cout << "\n\n\t\t===INVAILD CHOICE===" ;
            }
        }
        else if(choice==5)
        {

            cout << "\n\t================================================" ;
            cout << "\n\t|\t CHOOSE 1 TO DISPLAY TASK LIST         |" ;
            cout << "\n\t|\t CHOOSE 2 TO DISPLAY TASK PRIORITY LIST|" ;
            cout << "\n\t================================================" ;
            cout << "\n\t ENTER YOUR CHOICE : " ;
            cin >> choice ;

            if(choice==1)
            {
                cout << "\n\t================================================" ;
                cout << "\n\t|\t CHOOSE 1 TO DISPLAY TASK NAME         |" ;
                cout << "\n\t|\t CHOOSE 2 TO DISPLAY TASK DETAILS      |" ;
                cout << "\n\t================================================" ;
                cout << "\n\t ENTER YOUR CHOICE : " ;
                cin >> choice ;

                if(choice==1)
                {
                    taskManager.display_task_names();
                }
                else if(choice==2)
                {
                    taskManager.display_task_details();
                }
                else
                {
                    cout << "\n\n\t\t===INVAILD CHOICE===" ;
                }
            }
            else if(choice==2)
            {
                priorityQueue.sort_tasks_by_priority();
                priorityQueue.displayPriorityQueue(taskManager);
            }
        }
        else if (choice == 6)
        {
            TaskManager* currentTask = taskManager.HEAD;

            // Enqueue all tasks from the task manager list
            while (currentTask != nullptr)
            {
                priorityQueue.enqueue(currentTask);
                currentTask = currentTask->next_task;
            }

            cout << "Task enqueued into the priority queue." << endl;
        }
        else if (choice == 7)
        {
            Task* dequeuedTask = priorityQueue.dequeue();
            if (dequeuedTask != nullptr)
            {
                cout << "Task dequeued from the priority queue:" << endl;
                dequeuedTask->display();
            }
        }
        if (choice == 8)
        {
            taskManager.sort_tasks_by_priority();
            cout << "\n === TASKS SORTED BY PRIORITY === " << endl;
        }
    }
    while(choice!=0);


}
