#include "TaskManager.h"
#include "TaskPriorityQueue.h"

TaskManager::TaskManager()
{
    priority_queue_ = new TaskPriorityQueue();
}

TaskManager::~TaskManager()
{
    //dtor
}

void TaskManager :: add_task()
{
    TaskManager* newTask = new TaskManager ;

    newTask->task.set_taskname(get_taskname()) ;
    newTask->task.set_date(get_date()) ;
    newTask->task.set_priority(get_priority()) ;
    if (!isPriorityAvailable(task.priority))
    {
        cout << "Priority " << priority << " is already in use. Please choose a different priority." << endl;
        return;
    }
    if(HEAD==nullptr)
    {
        HEAD = newTask ;
        newTask->prev_task=nullptr;
        newTask->next_task=nullptr;
        cout << "\n === TASK ADDED SUCCESFULLY === " ;
    }
    else
    {
        TaskManager* Temp = HEAD ;
        while(Temp->next_task!=nullptr)
        {
            Temp = Temp->next_task ;
        }
        Temp->next_task = newTask ;
        newTask->prev_task=Temp;
        newTask->next_task=nullptr;
        cout << "\n === TASK ADDED SUCCESFULLY === " ;
    }
}

void TaskManager::remove_task(const string& TaskName)
{
    TaskManager* temp = HEAD;
    while (temp!=nullptr && temp->task.taskname!=TaskName)
    {
        temp = temp->next_task;
    }
    if (temp==nullptr)
    {
        cout << "Task with TaskName '" << TaskName << "' not found." << endl;
        return;
    }
    if (temp->prev_task!=nullptr)
    {
        temp->prev_task->next_task = temp->next_task;
    }
    else
    {
        HEAD = temp->next_task;
    }
    if (temp->next_task!=nullptr)
    {
        temp->next_task->prev_task = temp->prev_task;
    }
    delete temp;
    cout << "Task with TaskName '" << TaskName << "' removed successfully." << endl;
}

void TaskManager :: update_task_priority(const string& taskname, int newPriority)
{
    TaskManager* temp = HEAD;
    while (temp!=nullptr && temp->task.taskname!=taskname)
    {
        temp = temp->next_task;
    }

    if (temp == nullptr)
    {
        cout << "Task with TaskName '" << taskname << "' not found." << endl;
        return;
    }

    temp->task.set_priority(newPriority);

    cout << "Task with TaskName '" << taskname << "' updated successfully." << endl;
}

void TaskManager::update_task_name(const string& currentTaskName, const string& newTaskName)
{
    TaskManager* temp = HEAD;
    while (temp!=nullptr && temp->task.taskname!=currentTaskName)
    {
        temp = temp->next_task;
    }

    if (temp==nullptr)
    {
        cout << "Task with TaskName '" << currentTaskName << "' not found." << endl;
        return;
    }

    temp->task.set_taskname(newTaskName);

    cout << "Task with TaskName '" << currentTaskName << "' updated to '" << newTaskName << "' successfully." << endl;
}

void TaskManager::update_task_date(const string& taskName, const string& newDate)
{
    TaskManager* temp = HEAD;
    while (temp != nullptr && temp->task.taskname != taskName)
    {
        temp = temp->next_task;
    }

    if (temp == nullptr)
    {
        cout << "Task with TaskName '" << taskName << "' not found." << endl;
        return;
    }

    temp->task.set_date(newDate);

    cout << "Due date for Task with TaskName '" << taskName << "' updated to '" << newDate << "' successfully." << endl;
}


Task* TaskManager :: find_task_by_name(const string& taskName)
{
    TaskManager* temp = HEAD;
    while (temp!=nullptr && temp->task.taskname!=taskName)
    {
        temp = temp->next_task;
    }

    if (temp == nullptr)
    {
        cout << "Task with TaskName '" << taskName << "' not found." << endl;
        return nullptr;
    }

    return &(temp->task);
}

Task* TaskManager :: find_task_by_priority(int priority)
{
    TaskManager* temp = HEAD;
    while (temp!=nullptr && temp->task.priority!=priority)
    {
        temp = temp->next_task;
    }

    if (temp==nullptr)
    {
        cout << "Task with Priority '" << priority << "' not found." << endl;
        return nullptr;
    }

    return &(temp->task);
}


void TaskManager :: display_task_names()
{
    TaskManager* temp = HEAD ;
    while(temp!=nullptr)
    {
        temp->task.display_task_name() ;
        temp = temp->next_task ;
    }
}

bool TaskManager::isPriorityAvailable(int priority)
{
    TaskManager* temp = HEAD;
    while (temp != nullptr)
    {
        if (temp->task.priority == priority)
        {
            return false;
        }
        temp = temp->next_task;
    }
    return true;
}

void TaskManager::sort_tasks_by_priority()
{
    bool swapped;
    TaskManager* temp;
    TaskManager* last = nullptr;

    if (HEAD == nullptr)
        return;

    do
    {
        swapped = false;
        temp = HEAD;

        while (temp->next_task != last)
        {
            if (temp->task.priority > temp->next_task->task.priority)
            {
                swap_tasks(temp, temp->next_task);
                swapped = true;
            }
            temp = temp->next_task;
        }
        last = temp;
    } while (swapped);
}

void TaskManager::swap_tasks(TaskManager* task1, TaskManager* task2)
{
    Task temp = task1->task;
    task1->task = task2->task;
    task2->task = temp;
}


void TaskManager :: display_task_details()
{
    TaskManager* temp = HEAD ;
    while(temp!=nullptr)
    {
        temp->task.display() ;
        temp = temp->next_task ;
    }
}
