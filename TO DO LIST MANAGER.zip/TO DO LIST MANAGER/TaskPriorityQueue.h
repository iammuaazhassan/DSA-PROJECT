#ifndef TASKPRIORITYQUEUE_H
#define TASKPRIORITYQUEUE_H

#include "TaskManager.h"

struct Node
{
    Task* task;
    Node* next;
    Node(Task* t) : task(t), next(nullptr) {}
};

class TaskPriorityQueue
{
    private:
        Node* front;

    public:
        TaskPriorityQueue();
        ~TaskPriorityQueue();

        void enqueue(TaskManager* );
        Task* dequeue();
        bool isEmpty();

        bool isTaskInQueue(Task*);
        void sort_tasks_by_priority();
        void displayPriorityQueue(const TaskManager&);
};

#endif // TASKPRIORITYQUEUE_H
