#include "TaskPriorityQueue.h"
#include "TaskManager.h"
#include "Task.h"
#include <iostream>

TaskPriorityQueue::TaskPriorityQueue()
{
    front = nullptr;
}

TaskPriorityQueue::~TaskPriorityQueue()
{
    while (!isEmpty())
    {
        dequeue();
    }
}

void TaskPriorityQueue::enqueue(TaskManager* taskManager)
{
    Task* task = &(taskManager->task);

    if (isTaskInQueue(task))
    {
        return;
    }

    Node* newNode = new Node(task);
    if (isEmpty())
    {
        newNode->next = front;
        front = newNode;
    }
    else
    {
        Node* current = front;
        while (current->next != nullptr)
        {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }
    cout << "Task enqueued into the priority queue." << endl;
}

bool TaskPriorityQueue::isTaskInQueue(Task* taskToCheck)
{
    Node* current = front;
    while (current != nullptr)
    {
        if (current->task->taskname == taskToCheck->taskname)
        {
            return true;
        }
        current = current->next;
    }
    return false;
}


Task *TaskPriorityQueue::dequeue()
{
    if (isEmpty())
    {
        std::cout << "Priority queue is empty." << std::endl;
        return nullptr;
    }

    Task *task = front->task;
    Node *temp = front;
    front = front->next;
    delete temp;
    return task;
}

void TaskPriorityQueue::sort_tasks_by_priority()
{
    bool swapped;
    Node* temp;
    Node* last = nullptr;

    if (front == nullptr)
        return;

    do
    {
        swapped = false;
        temp = front;

        while (temp->next != last)
        {
            if (temp->task->priority > temp->next->task->priority)
            {
                // Swap tasks in the nodes
                Task* tempTask = temp->task;
                temp->task = temp->next->task;
                temp->next->task = tempTask;

                swapped = true;
            }
            temp = temp->next;
        }
        last = temp;
    } while (swapped);
}


bool TaskPriorityQueue::isEmpty()
{
    return front == nullptr;
}

void TaskPriorityQueue::displayPriorityQueue(const TaskManager &taskManager)
{
    Node *current = front;
    while (current != nullptr)
    {
        current->task->display();
        current = current->next;
    }
}
